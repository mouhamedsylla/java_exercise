/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.schedulemanager;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sylla
 */
public class Admin extends javax.swing.JFrame {

    Connection con;
    Statement stat, stat1;
    DefaultTableModel model;
    public Admin() {
        initComponents();
        Object[][] rowdata = null;
        Object[] columndata = {"nom", "prenom", "statut", "identification"};
        model = new DefaultTableModel(rowdata, columndata);
        AccessTab.setModel(model);

        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jCheckBoxMenuItem2 = new javax.swing.JCheckBoxMenuItem();
        jCheckBoxMenuItem3 = new javax.swing.JCheckBoxMenuItem();
        jCheckBoxMenuItem4 = new javax.swing.JCheckBoxMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        AStype = new javax.swing.JComboBox<>();
        ASnom = new javax.swing.JTextField();
        ASprenom = new javax.swing.JTextField();
        ASDepMat = new javax.swing.JTextField();
        AdminDelete = new javax.swing.JButton();
        AdminAdd = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        ASpassword = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        textSearch = new javax.swing.JTextField();
        Search = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        AccessTab = new javax.swing.JTable();
        AcessBlock = new javax.swing.JCheckBox();
        AccessNoBlock = new javax.swing.JCheckBox();
        AdminAccess = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        jCheckBoxMenuItem2.setSelected(true);
        jCheckBoxMenuItem2.setText("jCheckBoxMenuItem2");

        jCheckBoxMenuItem3.setSelected(true);
        jCheckBoxMenuItem3.setText("jCheckBoxMenuItem3");

        jCheckBoxMenuItem4.setSelected(true);
        jCheckBoxMenuItem4.setText("jCheckBoxMenuItem4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(149, 219, 251));

        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel1.setText("Administrateur");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray, null, null));

        jTabbedPane1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.lightGray, java.awt.Color.black, null));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.lightGray, null, null));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Ajouter / Supprimer");
        jLabel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.lightGray, null, null));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setText("Nom");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setText("Prénom");

        jLabel7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel7.setText("Dép/Matière");

        AStype.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enseignant", "Directeur Scolarité", "Chef Département" }));
        AStype.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                AStypeItemStateChanged(evt);
            }
        });

        AdminDelete.setIcon(new javax.swing.ImageIcon("C:\\Users\\sylla\\OneDrive\\Documents\\NetBeansProjects\\ScheduleManager\\src\\main\\java\\com\\mycompany\\schedulemanager\\image\\delete-icon.png")); // NOI18N
        AdminDelete.setText("Supprimé");
        AdminDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminDeleteActionPerformed(evt);
            }
        });

        AdminAdd.setIcon(new javax.swing.ImageIcon("C:\\Users\\sylla\\OneDrive\\Documents\\NetBeansProjects\\ScheduleManager\\src\\main\\java\\com\\mycompany\\schedulemanager\\image\\text-plus-icon.png")); // NOI18N
        AdminAdd.setText("Ajouté");
        AdminAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminAddActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setText("Password");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(94, 94, 94)
                .addComponent(AdminDelete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(AdminAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(97, 97, 97))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AStype, 0, 168, Short.MAX_VALUE)
                    .addComponent(ASnom)
                    .addComponent(ASprenom)
                    .addComponent(ASDepMat)
                    .addComponent(ASpassword))
                .addGap(50, 50, 50))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(AStype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(ASnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(ASprenom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(ASDepMat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(ASpassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(AdminAdd)
                        .addGap(40, 40, 40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(AdminDelete)
                        .addGap(48, 48, 48))))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.lightGray, null, null));

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setText("Modifier accès");
        jLabel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.darkGray, java.awt.Color.lightGray, null, null));

        textSearch.setBorder(javax.swing.BorderFactory.createCompoundBorder(null, javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.lightGray, java.awt.Color.lightGray, null, null)));
        textSearch.setOpaque(true);

        Search.setIcon(new javax.swing.ImageIcon("C:\\Users\\sylla\\OneDrive\\Documents\\NetBeansProjects\\ScheduleManager\\src\\main\\java\\com\\mycompany\\schedulemanager\\image\\search-icon.png")); // NOI18N
        Search.setText("Search");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });

        AccessTab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom", "Prenom", "Statut", "Identification"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                true, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(AccessTab);

        AcessBlock.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        AcessBlock.setText("bloqué");

        AccessNoBlock.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        AccessNoBlock.setText("autorisé");

        AdminAccess.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        AdminAccess.setIcon(new javax.swing.ImageIcon("C:\\Users\\sylla\\OneDrive\\Documents\\NetBeansProjects\\ScheduleManager\\src\\main\\java\\com\\mycompany\\schedulemanager\\image\\apply-icon.png")); // NOI18N
        AdminAccess.setText("Submit");
        AdminAccess.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AdminAccessActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Microsoft YaHei Light", 0, 8)); // NOI18N
        jLabel8.setText("*entré ici un nom ex: Sylla");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(AdminAccess)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel6Layout.createSequentialGroup()
                                    .addComponent(textSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(Search))
                                .addComponent(AcessBlock, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(AccessNoBlock, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 469, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 17, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Search))
                .addGap(2, 2, 2)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AcessBlock)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AccessNoBlock)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AdminAccess)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Gestion des accès", jPanel2);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1045, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 379, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Infos salles", jPanel3);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, null, java.awt.Color.lightGray, java.awt.Color.black, null));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        if(evt.getSource()==Search){
            model.setRowCount(0);
        }
        con = DbConnection.getConnection();
        ArrayList<String> table = new ArrayList();
        try{
            DatabaseMetaData md = con.getMetaData();
            ResultSet rs = md.getTables(null, null, "%", null);
            while (rs.next()) {
            table.add(rs.getString(3));
            }
            table.remove(2);
            table.remove(5);
            
            String nom = textSearch.getText();
            int row = 0;
            int column = 0;
            for(int i = 1; i<table.size(); i++) {

                stat = con.createStatement();
                String myTable = table.get(i);
                String sql = "SELECT nom, prenom, statut, identification FROM "+myTable+" WHERE nom = '"+nom+"'";
                rs = stat.executeQuery(sql);

                while(rs.next()) {
                    String rsnom = rs.getString("nom");
                    String rsprenom = rs.getString("prenom");
                    String rstatut = rs.getString("statut");
                    int id = rs.getInt("identification");
                    Object[][] rowdata = {{rsnom, rsprenom, rstatut, id}};
                    model.addRow(rowdata[0]);
                }
                row++;
                column = 0;
            }

             
            }catch(SQLException e) {
                e.printStackTrace();
            }finally{
                try{
                    if(con!=null) con.close();
                }catch(SQLException e) {
                    e.printStackTrace();
                }
        }
    }//GEN-LAST:event_SearchActionPerformed

    private void AdminAccessActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminAccessActionPerformed
        if(evt.getSource()==AdminAccess) {
        int index = AccessTab.getSelectedRow();
        String ident = String.valueOf(AccessTab.getValueAt(index, 3));
        String statu = String.valueOf(AccessTab.getValueAt(index, 2));
        int id = Integer.valueOf(ident);
        
        con = DbConnection.getConnection();
        try {
            stat1 = con.createStatement();
            if(AcessBlock.isSelected()){
            String sql = "UPDATE "+statu+" set access = 0 WHERE identification = "+id+"";
            stat1.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Utilisateur bloqué");
            AcessBlock.setSelected(false);
            }
            if(AccessNoBlock.isSelected()){
            String sql = "UPDATE "+statu+" set access = 1 WHERE identification = "+id+"";
            stat1.executeUpdate(sql);
            JOptionPane.showMessageDialog(null, "Utilisateur débloqué");
            AccessNoBlock.setSelected(false);
            }
            
        }catch(SQLException e) {
            e.printStackTrace();
        }
        finally{
                try{
                    if(con!=null) con.close();
                }catch(SQLException e) {
                    e.printStackTrace();
                }
        }
        }
    }//GEN-LAST:event_AdminAccessActionPerformed

    private void AdminAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminAddActionPerformed
        if(evt.getSource()==AdminAdd) {
            con = DbConnection.getConnection();
            try {
                String nom = ASnom.getText();
                String prenom = ASprenom.getText();
                String password = ASpassword.getText();
                String dep_mat = ASDepMat.getText();
                stat = con.createStatement();
                String sql = "";
                
                String acteur = String.valueOf(AStype.getSelectedItem());
                switch(acteur) {
                    case "Enseignant":
                        sql = "INSERT INTO Enseignant(nom, prenom, password, matiere) VALUES('"+nom+"', '"+prenom+"', '"+password+"', '"+dep_mat+"')";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur ajouté");
                        break;
                    case "Chef Département":
                        sql = "INSERT INTO ChefDepartement(nom, prenom, password, nomDepartement) VALUES('"+nom+"', '"+prenom+"', '"+password+"', '"+dep_mat+"')";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur ajouté");
                        break;
                    case "Directeur Scolarité":
                        sql = "INSERT INTO DirScolarite(nom, prenom, password) VALUES('"+nom+"', '"+prenom+"', '"+password+"')";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur ajouté");
                        break;
                }
                
            }catch(SQLException e) {
                e.printStackTrace();
            }finally{
                try{
                    if(con!=null)
                        con.close();
                }catch(SQLException e) {
                    e.printStackTrace();
                }
            }
            
        }
    }//GEN-LAST:event_AdminAddActionPerformed

    private void AStypeItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_AStypeItemStateChanged
        String acteur = String.valueOf(AStype.getSelectedItem());
        if(acteur=="Directeur Scolarité") {
            ASDepMat.setEnabled(false);
        }
        else{
            ASDepMat.setEnabled(true);
        }
    }//GEN-LAST:event_AStypeItemStateChanged

    private void AdminDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AdminDeleteActionPerformed
        con = DbConnection.getConnection();
        try {
                String nom = ASnom.getText();
                String prenom = ASprenom.getText();
                String password = ASpassword.getText();
                String dep_mat = ASDepMat.getText();
                stat = con.createStatement();
                String sql = "";
                
                String acteur = String.valueOf(AStype.getSelectedItem());
                switch(acteur) {
                    case "Enseignant":
                        sql = "DELETE FROM Enseignant WHERE nom = '"+nom+"' AND prenom = '"+prenom+"' AND password = '"+password+"' AND matiere = '"+dep_mat+"'";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur supprimé");
                        break;
                    case "Chef Département":
                        sql = "DELETE FROM ChefDepartement WHERE nom = '"+nom+"' AND prenom = '"+prenom+"' AND password = '"+password+"' AND nomDepartement = '"+dep_mat+"'";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur supprimé");
                        break;
                    case "Directeur Scolarité":
                        sql = "DELETE FROM DirScolarite WHERE nom = '"+nom+"' AND prenom = '"+prenom+"' AND password = '"+password+"'";
                        stat.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Utilisateur supprimé");
                        break;
                }
                
            }catch(SQLException e) {
                e.printStackTrace();
            }finally{
                try{
                    if(con!=null)
                        con.close();
                }catch(SQLException e) {
                    e.printStackTrace();
                }
            }
            
        
    }//GEN-LAST:event_AdminDeleteActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ASDepMat;
    private javax.swing.JTextField ASnom;
    private javax.swing.JTextField ASpassword;
    private javax.swing.JTextField ASprenom;
    private javax.swing.JComboBox<String> AStype;
    private javax.swing.JCheckBox AccessNoBlock;
    private javax.swing.JTable AccessTab;
    private javax.swing.JCheckBox AcessBlock;
    private javax.swing.JButton AdminAccess;
    private javax.swing.JButton AdminAdd;
    private javax.swing.JButton AdminDelete;
    private javax.swing.JButton Search;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem2;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem3;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField textSearch;
    // End of variables declaration//GEN-END:variables
}
